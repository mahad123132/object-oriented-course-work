public class Lecturer extends User {
    private String department;

    public Lecturer(String id, String name, String email, String password, String department) {
        super(id, name, email, password);
        this.department = department;
    }

    // Getter and Setter
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    // Override requestTransport
    @Override
    public String requestTransport() {
        return "Lecturer " + getName() + " requests transport for departmental duties.";
    }
}