public class Van extends Vehicle {
    private boolean isCargo;

    public Van(String vehicleId, String model, int year, boolean isCargo) {
        super(vehicleId, model, year);
        this.isCargo = isCargo;
    }

    // Getter and Setter
    public boolean isCargo() { return isCargo; }
    public void setCargo(boolean isCargo) { this.isCargo = isCargo; }
}