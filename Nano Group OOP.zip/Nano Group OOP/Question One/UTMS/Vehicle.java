public abstract class Vehicle implements Serviceable, Trackable, Schedulable {
    private String vehicleId;
    private String model;
    private int year;
    private boolean serviceDue;
    private String currentLocation;
    private String assignedRoute;

    public Vehicle(String vehicleId, String model, int year) {
        this.vehicleId = vehicleId;
        this.model = model;
        this.year = year;
        this.serviceDue = false;
        this.currentLocation = "Campus Depot";
        this.assignedRoute = "None";
    }

    // Getters and Setters
    public String getVehicleId() { return vehicleId; }
    public void setVehicleId(String vehicleId) { this.vehicleId = vehicleId; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    // Interface implementations
    @Override
    public void scheduleMaintenance() {
        this.serviceDue = true;
        System.out.println("Maintenance scheduled for vehicle: " + vehicleId);
    }

    @Override
    public boolean isServiceDue() {
        return serviceDue;
    }

    @Override
    public String getCurrentLocation() {
        return currentLocation;
    }

    @Override
    public void assignRoute(String route) {
        this.assignedRoute = route;
        System.out.println("Assigned route " + route + " to vehicle: " + vehicleId);
    }
}