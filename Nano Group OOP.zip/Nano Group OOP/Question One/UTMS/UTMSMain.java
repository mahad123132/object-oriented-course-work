public class UTMSMain {
    public static void main(String[] args) {
        // Create users
        User student = new Student("S001", "Abdallah Kizito", "kizitopabdallah0@gmail.com", "pass123", "VU-DIT-2407-0832-DAY");
        User lecturer = new Lecturer("L001", "Eng. Alex Bazigu", "balex@gmail.com", "pass456", "Computer Science");
        User officer = new TransportOfficer("T001", "Mahad Semakula", "ssemakulamahad@gmail.com", "pass789", "Senior");

        // Demonstrate polymorphism with requestTransport
        System.out.println(student.requestTransport());
        System.out.println(lecturer.requestTransport());
        System.out.println(officer.requestTransport());

        // Demonstrate method overloading
        TransportOfficer transportOfficer = (TransportOfficer) officer;
        System.out.println(transportOfficer.assignDriver("Emmanuel", "Bus"));
        System.out.println(transportOfficer.assignDriver("Abel", "Van", "Morning"));

        // Create vehicles
        Vehicle bus = new Bus("UBD235A", "Volvo", 2020, 50);
        Vehicle van = new Van("UBD236A", "Toyota", 2019, true);

        // Demonstrate interface methods
        bus.scheduleMaintenance();
        System.out.println("Is bus service due? " + bus.isServiceDue());
        bus.assignRoute("Market plaza to Victoria Plaza");
        System.out.println("Bus location: " + bus.getCurrentLocation());

        van.scheduleMaintenance();
        System.out.println("Is van service due? " + van.isServiceDue());
        van.assignRoute("Main campus to marketplaza");
        System.out.println("Van location: " + van.getCurrentLocation());
    }
}