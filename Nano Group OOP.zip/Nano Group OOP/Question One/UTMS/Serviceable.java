public interface Serviceable {
    void scheduleMaintenance();
    boolean isServiceDue();
}