public interface Schedulable {
    void assignRoute(String route);
}