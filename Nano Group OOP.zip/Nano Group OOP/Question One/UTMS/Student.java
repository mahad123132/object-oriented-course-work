public class Student extends User {
    private String studentId;

    public Student(String id, String name, String email, String password, String studentId) {
        super(id, name, email, password);
        this.studentId = studentId;
    }

    // Getter and Setter
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    // Override requestTransport
    @Override
    public String requestTransport() {
        return "Student " + getName() + " requests transport to campus.";
    }
}