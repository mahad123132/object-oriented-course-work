public class Bus extends Vehicle {
    private int capacity;

    public Bus(String vehicleId, String model, int year, int capacity) {
        super(vehicleId, model, year);
        this.capacity = capacity;
    }

    // Getter and Setter
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
}