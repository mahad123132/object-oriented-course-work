public class Driver {
    private String licenseNumber;
    private String name;

    public Driver(String licenseNumber, String name) {
        this.licenseNumber = licenseNumber;
        this.name = name;
    }

    // Getters and Setters
    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) { this.licenseNumber = licenseNumber; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}