public class TransportOfficer extends User {
    private String officerLevel;

    public TransportOfficer(String id, String name, String email, String password, String officerLevel) {
        super(id, name, email, password);
        this.officerLevel = officerLevel;
    }

    // Getter and Setter
    public String getOfficerLevel() { return officerLevel; }
    public void setOfficerLevel(String officerLevel) { this.officerLevel = officerLevel; }

    // Override requestTransport
    @Override
    public String requestTransport() {
        return "Transport Officer " + getName() + " requests transport for inspection.";
    }

    // Overloaded assignDriver methods
    public String assignDriver(String driverName, String vehicleType) {
        return "Assigned driver " + driverName + " to vehicle type: " + vehicleType;
    }

    public String assignDriver(String driverName, String vehicleType, String shiftTime) {
        return "Assigned driver " + driverName + " to vehicle type: " + vehicleType + " for shift: " + shiftTime;
    }
}