public interface Trackable {
    String getCurrentLocation();
}