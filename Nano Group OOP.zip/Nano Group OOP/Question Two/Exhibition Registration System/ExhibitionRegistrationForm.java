import java.awt.*;
import javax.swing.*;


public class ExhibitionRegistrationForm extends JFrame {

    // Declare form components
    JTextField txtRegID, txtName, txtFaculty, txtProjectTitle, txtContact, txtEmail, txtImagePath;
    JLabel lblImage;
    JButton btnRegister, btnSearch, btnUpdate, btnDelete, btnClear, btnExit, btnUpload;

    public ExhibitionRegistrationForm() {
        setTitle("VU Exhibition Registration System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Labels and fields
        JLabel lblTitle = new JLabel("VU Innovation & Tech Exhibition");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setBounds(250, 10, 400, 30);
        add(lblTitle);

        addLabelAndField("Registration ID:", 60, txtRegID = new JTextField());
        addLabelAndField("Student Name:", 100, txtName = new JTextField());
        addLabelAndField("Faculty:", 140, txtFaculty = new JTextField());
        addLabelAndField("Project Title:", 180, txtProjectTitle = new JTextField());
        addLabelAndField("Contact Number:", 220, txtContact = new JTextField());
        addLabelAndField("Email Address:", 260, txtEmail = new JTextField());
        addLabelAndField("Image Path:", 300, txtImagePath = new JTextField());
        txtImagePath.setEditable(false);

        // Upload Image
        btnUpload = new JButton("Upload Image");
        btnUpload.setBounds(600, 300, 140, 25);
        add(btnUpload);

        lblImage = new JLabel();
        lblImage.setBounds(500, 340, 250, 180);
        add(lblImage);

        // Buttons
        String[] btnLabels = {"Register", "Search", "Update", "Delete", "Clear", "Exit"};
        JButton[] buttons = new JButton[btnLabels.length];
        int x = 50;

        for (int i = 0; i < btnLabels.length; i++) {
            buttons[i] = new JButton(btnLabels[i]);
            buttons[i].setBounds(x, 500, 100, 30);
            add(buttons[i]);
            x += 110;
        }

        // Assign buttons
        btnRegister = buttons[0];
        btnSearch = buttons[1];
        btnUpdate = buttons[2];
        btnDelete = buttons[3];
        btnClear = buttons[4];
        btnExit = buttons[5];

        setVisible(true);
    }

    private void addLabelAndField(String label, int y, JTextField textField) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(50, y, 150, 25);
        textField.setBounds(200, y, 350, 25);
        add(lbl);
        add(textField);
    }

    public static void main(String[] args) {
        new ExhibitionRegistrationForm();
    }
}
