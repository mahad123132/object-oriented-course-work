import java.sql.*;

public void registerParticipant() {
    String sql = "INSERT INTO Participants (RegistrationID, StudentName, Faculty, ProjectTitle, ContactNumber, EmailAddress, ImagePath) VALUES (?, ?, ?, ?, ?, ?, ?)";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, txtRegID.getText());
        pst.setString(2, txtName.getText());
        pst.setString(3, txtFaculty.getText());
        pst.setString(4, txtProjectTitle.getText());
        pst.setString(5, txtContact.getText());
        pst.setString(6, txtEmail.getText());
        pst.setString(7, txtImagePath.getText());

        int rows = pst.executeUpdate();
        if (rows > 0) {
            JOptionPane.showMessageDialog(this, "Participant Registered Successfully!");
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}
