public void updateParticipant() {
    String sql = "UPDATE Participants SET StudentName=?, Faculty=?, ProjectTitle=?, ContactNumber=?, EmailAddress=?, ImagePath=? WHERE RegistrationID=?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, txtName.getText());
        pst.setString(2, txtFaculty.getText());
        pst.setString(3, txtProjectTitle.getText());
        pst.setString(4, txtContact.getText());
        pst.setString(5, txtEmail.getText());
        pst.setString(6, txtImagePath.getText());
        pst.setString(7, txtRegID.getText());

        int rows = pst.executeUpdate();
        if (rows > 0) {
            JOptionPane.showMessageDialog(this, "Update successful.");
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Update error: " + ex.getMessage());
    }
}
