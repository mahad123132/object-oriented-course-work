public void searchParticipant() {
    String sql = "SELECT * FROM Participants WHERE RegistrationID = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, txtRegID.getText());
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            txtName.setText(rs.getString("StudentName"));
            txtFaculty.setText(rs.getString("Faculty"));
            txtProjectTitle.setText(rs.getString("ProjectTitle"));
            txtContact.setText(rs.getString("ContactNumber"));
            txtEmail.setText(rs.getString("EmailAddress"));
            txtImagePath.setText(rs.getString("ImagePath"));

            ImageIcon icon = new ImageIcon(rs.getString("ImagePath"));
            lblImage.setIcon(new ImageIcon(icon.getImage().getScaledInstance(250, 180, Image.SCALE_SMOOTH)));

        } else {
            JOptionPane.showMessageDialog(this, "No record found.");
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
    }
}
