public void deleteParticipant() {
    String sql = "DELETE FROM Participants WHERE RegistrationID = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, txtRegID.getText());

        int rows = pst.executeUpdate();
        if (rows > 0) {
            JOptionPane.showMessageDialog(this, "Participant deleted.");
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Delete error: " + ex.getMessage());
    }
}
